#include <stdio.h>
#include <time.h>
#include <sys/time.h>
#include <signal.h>
#include <unistd.h>

struct itimerval old_timer;

void delay(clock_t n)
{
    clock_t start = clock();
    while(clock() - start < n);
}

void pause_timer()
{
    struct itimerval zero_timer = { 0 };

    setitimer(ITIMER_REAL,  &zero_timer, &old_timer);
}

void resume_timer()
{
    setitimer(ITIMER_REAL, &old_timer, NULL);
}

void alarm_handler (int signo)
{
	printf ("Timer hit!\n");
}

void foo (void)
{
	///struct itimerval delay;
	int ret;

	signal (SIGALRM, alarm_handler);

	old_timer.it_value.tv_sec = 1;
	old_timer.it_value.tv_usec = 0;
	old_timer.it_interval.tv_sec = 1;
	old_timer.it_interval.tv_usec = 0;

    ///new timer setting
	ret = setitimer (ITIMER_REAL, &old_timer, NULL);
	///ret = setitimer (ITIMER_VIRTUAL, &old_timer, NULL);
	///ret = setitimer (ITIMER_PROF, &old_timer, NULL);
	if (ret) {
		perror ("setitimer");
		return;
	}
	///pause ();
}

int main (void)
{
    ///int i;

	foo (); ///setting timer

	while(1)
	{
        ///sleep(10);

        printf("pause_timer()\r\n");
        pause_timer();
        sleep(5);

        printf("resume_timer()\r\n");

        resume_timer();
        ///sleep(10);
        delay(10000000);  ///us, 10s
	}
	return 0;
}
