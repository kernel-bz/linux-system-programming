extern int     gx_set_font( char *FontFileName);
extern void    gx_text_out( dc_t *dc , int coor_x, int coor_y, char *chrText);
